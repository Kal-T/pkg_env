#! /bin/bash

cd /usr/share/jobarranger/api/script
php -q cleanup.php > /dev/null &
exit 0
