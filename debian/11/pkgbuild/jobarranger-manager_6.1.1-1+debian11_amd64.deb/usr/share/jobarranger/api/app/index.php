<?php
  
    //Require libraries from folder libraries
    require_once('../vendor/autoload.php');
    require_once 'Utils/Controller.php';
    require_once 'Utils/Monolog.php';
    require_once 'Utils/Router.php';
    $router = new Router();
    $router->resolve();
